async function listAPI() {
    const connectionAPI = await fetch(`http://localhost:3000/products`);
    const dataAPI = connectionAPI.json();
    console.log(dataAPI);
    return dataAPI
};

async function createProduct(name, size, price, stock, url,id) {
    const connetion = await fetch('http://localhost:3000/products',{
        method: 'POST',
        headers: {'content-type':'application/json'},
        body: JSON.stringify({
            id: id,
            name: name,
            size: size,
            price: price,
            stock: `${stock}`,
            url: url,
        })
    });
    const dataAPI = connetion.json();
    
    
    if(!connetion.ok) {
        throw new Error('Ha ocurrido un error al ingresar el producto');
    }
    return dataAPI.id;
};

async function deleteProduct(id) {
    const url = `http://localhost:3000/products/${id}`;
    try {
        const respose = await fetch(url,{
            method: 'DELETE',
        });
        if (!respose.ok) {
            throw new Error ('error!');
        }
        console.log('objeto ',id, ' eliminado');
    } catch (error) {
        console.error('Error: ', error);
    }
    
}


export {listAPI, createProduct, deleteProduct};

